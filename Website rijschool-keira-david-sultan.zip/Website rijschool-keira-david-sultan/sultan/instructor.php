<?php
session_start();

// Check if the user is logged in and has instructor role, if not redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'instructor') {
  header("location: instructor_login.php");
  exit;
}

// Display the instructor dashboard
echo "Welcome to the instructor dashboard, " . $_SESSION["email"] . "!";

// Add a logout button
echo "<br><br><a href='logout.php'>Logout</a>";


// Create connection to the database
$conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");
// Check if the connection was successful
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Get the instructor id from the session
$instructeur_id = $_SESSION["user_id"];

// Prepare and execute the query to get the car information for the instructor
$query = "SELECT auto.merk, auto.brandstof_type, auto.klaar_om_te_rijden, auto.beschrijving 
        FROM instructeur
        LEFT JOIN auto ON instructeur.auto_id = auto.auto_id
        WHERE instructeur.instructeur_id = $instructeur_id";
$result = mysqli_query($conn, $query);

// Check if any rows were returned
if (mysqli_num_rows($result) > 0) {
  // Display the car information
  $row = mysqli_fetch_assoc($result);
  echo "Car brand: " . $row["merk"] . "<br>";
  echo "Car model: " . $row["brandstof_type"] . "<br>";
  echo "Status: " . $row["klaar_om_te_rijden"] . "<br>";
  echo "Description: " . $row["beschrijving"] . "<br>";
} else {
  // No rows were returned
  echo "No car assigned.<br>";
  echo "Please contact the admin to be assigned a car.";
}

// Get the instructor id from the session
$instructeur_id = $_SESSION["user_id"];

// Prepare and execute the query to get the lessons and their comments
$query = "SELECT lessen.*, feedback.inhoud AS comment, leerlingen.gebruikersnaam AS student_name FROM lessen LEFT JOIN feedback ON lessen.les_id = feedback.les_id LEFT JOIN leerlingen ON lessen.gebruikers_id = leerlingen.gebruikers_id WHERE lessen.instructeur_id = $instructeur_id ORDER BY lessen.lestijd_start DESC";
$result = mysqli_query($conn, $query);

// Check if any rows were returned
if (mysqli_num_rows($result) > 0) {
  // Display the lessons and their comments in a table
  echo "<h2>Your lessons:</h2>";
  echo "<table>";
  echo "<tr><th>Lesson ID</th><th>Start Time</th><th>End Time</th><th>Goal</th><th>Pickup Location</th><th>Student Name</th><th>Comment</th></tr>";
  while($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row["les_id"] . "</td>";
    echo "<td>" . $row["lestijd_start"] . "</td>";
    echo "<td>" . $row["lestijd_eind"] . "</td>";
    echo "<td>" . $row["doel_van_les"] . "</td>";
    echo "<td>" . $row["ophaal_locatie"] . "</td>";
    echo "<td>" . $row["student_name"] . "</td>";
    echo "<td>" . $row["comment"] . "</td>";
    echo "</tr>";
  }
  echo "</table>";
} else {
  // No lessons were found
  echo "No lessons assigned to you.";
}


?>

<?php
require 'config.php';
$method = new Database();
$today = date("Y") . "-" . date('m') . "-" . date('d');

$who_is_sick = 1;


if (isset($_POST['datum'])) {
  $statement = 'INSERT INTO ziekmelding (instructeur_id, datum) VALUES (:id, :date)';
  $placeholders = ['id' => $who_is_sick, 'date' => $_POST['datum']];
  $method->db_activate($statement, $placeholders);
}
?>


<!-- Add a form to allow instructor to report sick days -->
<h2>Report a Sick Day</h2>
<form method='POST' action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>'>
  <label for='datum'>Date:</label>
  <input type='date' id='datum' name='datum' required>
  <input type='submit' name='submit' value='Report Sick Day'>
</form>







<?php
// Display the form for planning a lesson
echo "<h2>Plan a Lesson</h2>";
echo "<form action='' method='post'>";
echo "<label for='student_id'>Student:</label>";
echo "<select id='student_id' name='student_id' required>";
$query = "SELECT gebruikers_id, gebruikersnaam FROM leerlingen";
$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_assoc($result)) {
  echo "<option value='" . $row["gebruikers_id"] . "'>" . $row["gebruikersnaam"] . "</option>";
}
echo "</select><br>";
echo "<label for='lesson_date'>Lesson Date:</label>";
echo "<input type='date' id='lesson_date' name='lesson_date' required><br>";
echo "<label for='lesson_start'>Start Time:</label>";
echo "<input type='time' id='lesson_start' name='lesson_start' required><br>";
echo "<label for='lesson_end'>End Time:</label>";
echo "<input type='time' id='lesson_end' name='lesson_end' required><br>";
echo "<label for='goal'>Lesson Goal:</label>";
echo "<input type='text' id='goal' name='goal' required><br>";
echo "<label for='pickup_location'>Pickup Location:</label>";
echo "<input type='text' id='pickup_location' name='pickup_location' required><br>";
echo "<input type='submit' name='submit' value='Plan Lesson'>";
echo "</form>";

// Handle form submission
if (isset($_POST["submit"])) {
  // Get form data
  $student_id = $_POST["student_id"];
  $lesson_date = $_POST["lesson_date"];
  $lesson_start = $_POST["lesson_start"];
  $lesson_end = $_POST["lesson_end"];
  $goal = $_POST["goal"];
  $pickup_location = $_POST["pickup_location"];
  $instructeur_id = $_SESSION["user_id"];

  // Insert new lesson into the database
  $query = "INSERT INTO lessen (gebruikers_id, instructeur_id, lestijd_start, lestijd_eind, doel_van_les, ophaal_locatie, planned) 
  VALUES ('$student_id', '$instructeur_id', '$lesson_date $lesson_start', '$lesson_date $lesson_end', '$goal', '$pickup_location', 1)";
  $result = mysqli_query($conn, $query);

  if ($result) {
    // Display success message
    echo "<div class='success'>Lesson planned successfully.</div>";
  } else {
    // Display error message
    echo "<div class='error'>Error planning lesson: " . mysqli_error($conn) . "</div>";
  }
}


// Get planned lessons for the current instructor
$instructeur_id = $_SESSION["user_id"];
$query = "SELECT lessen.*, leerlingen.gebruikersnaam AS student_name FROM lessen INNER JOIN leerlingen ON lessen.gebruikers_id = leerlingen.gebruikers_id WHERE lessen.instructeur_id='$instructeur_id' AND lessen.planned=1 ORDER BY lessen.lestijd_start DESC";
$result = mysqli_query($conn, $query);

// Display the planned lessons in a table
echo "<h2>Planned Lessons</h2>";
if (mysqli_num_rows($result) > 0) {
  echo "<table>";
  echo "<tr><th>Lesson ID</th><th>Student Name</th><th>Lesson Date</th><th>Start Time</th><th>End Time</th><th>Goal</th><th>Pickup Location</th></tr>";
  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row["les_id"] . "</td>";
    echo "<td>" . $row["student_name"] . "</td>";
    echo "<td>" . date("d-m-Y", strtotime($row["lestijd_start"])) . "</td>";
    echo "<td>" . date("H:i", strtotime($row["lestijd_start"])) . "</td>";
    echo "<td>" . date("H:i", strtotime($row["lestijd_eind"])) . "</td>";
    echo "<td>" . $row["doel_van_les"] . "</td>";
    echo "<td>" . $row["ophaal_locatie"] . "</td>";
    echo "</tr>";
  }
  echo "</table>";
} else {
  echo "No planned lessons found.";
}

// Close the connection
mysqli_close($conn);
?>