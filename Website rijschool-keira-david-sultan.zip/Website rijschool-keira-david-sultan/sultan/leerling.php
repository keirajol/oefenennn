<?php
session_start();

// Check if the user is logged in, if not redirect to login page
if (!isset($_SESSION["user_id"])) {
  header("location: leerling_login.php");
  exit;
}

// Display the student dashboard
echo "Welcome to the student dashboard, " . $_SESSION["email"] . "!";

// Add a logout button
echo "<br><br><a href='logout.php'>Logout</a>";




// Connect to the database
$conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");

// Check if the connection was successful
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// Handle the form submission
if (isset($_POST["comment"]) && isset($_POST["les_id"])) {
  $comment = $_POST["comment"];
  $les_id = $_POST["les_id"];
  $instructeur_id = $_POST["instructeur_id"];
  $gebruikers_id = $_SESSION["user_id"];
  $post_date = date("Y-m-d");
  // Insert the new comment into the feedback table
  $query = "INSERT INTO feedback (les_id, instructeur_id, gebruikers_id, inhoud, post_datum) VALUES ('$les_id', '$instructeur_id', '$gebruikers_id', '$comment', '$post_date')";
  $result = mysqli_query($conn, $query);
  if ($result) {
    echo "<div class='success'>Comment added successfully.</div>";
  } else {
    echo "<div class='error'>Error adding comment: " . mysqli_error($conn) . "</div>";
  }
}

// Retrieve the lessons and instructor names for the current student from the database
$user_id = $_SESSION["user_id"];
$query = "SELECT lessen.*, instructeur.naam AS instructeur_naam FROM lessen INNER JOIN instructeur ON lessen.instructeur_id = instructeur.instructeur_id WHERE lessen.gebruikers_id='$user_id'";
$result = mysqli_query($conn, $query);

// Display the lessons and instructor names in a table, along with the comment form
echo "<h2>Your lessons:</h2>";
if (mysqli_num_rows($result) > 0) {
  echo "<table>";
  echo "<tr><th>Lesson ID</th><th>Start Time</th><th>End Time</th><th>Goal</th><th>Pickup Location</th><th>Instructor Name</th><th>Comment</th><th>Action</th></tr>";
  while($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row["les_id"] . "</td>";
    echo "<td>" . $row["lestijd_start"] . "</td>";
    echo "<td>" . $row["lestijd_eind"] . "</td>";
    echo "<td>" . $row["doel_van_les"] . "</td>";
    echo "<td>" . $row["ophaal_locatie"] . "</td>";
    echo "<td>" . $row["instructeur_naam"] . "</td>";
    // Display the comment input form for each lesson
    echo "<td>";
    echo "<form action='' method='post'>";
    echo "<input type='hidden' name='les_id' value='" . $row["les_id"] . "'>";
    echo "<input type='hidden' name='instructeur_id' value='" . $row["instructeur_id"] . "'>";
    echo "<input type='text' name='comment' placeholder='Enter a comment...'>";
    echo "</td>";
    echo "<td><input type='submit' value='Add Comment'></form></td>";
    echo "</tr>";
  }
  echo "</table>";
} else {
  echo "No lessons found.";
}

include '../david/wagenlijst.php';
?>



