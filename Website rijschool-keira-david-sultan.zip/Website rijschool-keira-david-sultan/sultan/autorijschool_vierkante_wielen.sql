SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `algemene_voorwaarden` (
  `Voorwaarden_ID` int(11) NOT NULL,
  `Voorwaarden` varchar(255) DEFAULT NULL,
  `Datum` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `algemene_voorwaarden` (`Voorwaarden_ID`, `Voorwaarden`, `Datum`) VALUES
(0, 'fdghgdfgdfg', '2023-04-19'),
(0, 'fdghgdfgdfg', '2023-04-19'),
(0, 'fffffff', '2023-04-19'),
(0, 'day3\r\n', '2023-04-19'),
(0, 'day3', '2023-04-19'),
(0, 'ili', '2023-04-19');

CREATE TABLE `auto` (
  `auto_id` int(11) NOT NULL,
  `merk` varchar(255) NOT NULL,
  `brandstof_type` varchar(255) NOT NULL,
  `klaar_om_te_rijden` tinyint(1) NOT NULL,
  `beschrijving` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `auto` (`auto_id`, `merk`, `brandstof_type`, `klaar_om_te_rijden`, `beschrijving`) VALUES
(1, 'LamberJamer', 'C02', 1, 'Dont touch my car!'),
(2, 'Bugattitti', 'Redbull', 1, 'Popin in ma Bugattitti');

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `les_id` int(11) NOT NULL,
  `instructeur_id` int(11) NOT NULL,
  `gebruikers_id` int(11) NOT NULL,
  `inhoud` varchar(255) NOT NULL,
  `post_datum` date NOT NULL,
  `placeholder` varchar(255) DEFAULT NULL,
  `instructeur_comment` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `feedback` (`feedback_id`, `les_id`, `instructeur_id`, `gebruikers_id`, `inhoud`, `post_datum`, `placeholder`, `instructeur_comment`) VALUES
(10, 15, 2, 2, 'test', '2023-04-19', NULL, NULL),
(11, 16, 1, 2, 'im sick today', '2023-04-19', NULL, NULL);

CREATE TABLE `instructeur` (
  `instructeur_id` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL,
  `auto_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `instructeur` (`instructeur_id`, `naam`, `email`, `wachtwoord`, `auto_id`) VALUES
(1, 'sultan', 'sultan@gmail.com', '1234', 2),
(2, 'ss', 'ss@gmail.com', '123', 1);

CREATE TABLE `leerlingen` (
  `gebruikers_id` int(11) NOT NULL,
  `gebruikersnaam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `leerlingen` (`gebruikers_id`, `gebruikersnaam`, `email`, `wachtwoord`) VALUES
(1, 'damn', 'damn@gmail.com', '1234'),
(2, 'Lora', 'lora@gmail.com', 'lora'),
(3, 'jeff', 'jeff@gmail.com', 'jeff123');

CREATE TABLE `lessen` (
  `les_id` int(11) NOT NULL,
  `lestijd_start` datetime NOT NULL,
  `lestijd_eind` datetime NOT NULL,
  `doel_van_les` varchar(255) NOT NULL,
  `ophaal_locatie` varchar(255) NOT NULL,
  `gebruikers_id` int(11) NOT NULL,
  `instructeur_id` int(11) NOT NULL,
  `auto_id` int(11) NOT NULL,
  `planned` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `lessen` (`les_id`, `lestijd_start`, `lestijd_eind`, `doel_van_les`, `ophaal_locatie`, `gebruikers_id`, `instructeur_id`, `auto_id`, `planned`) VALUES
(1, '2023-04-19 10:00:00', '2023-04-19 11:00:00', 'proefles', 'next to my home', 1, 1, 1, 0),
(2, '2023-04-20 11:00:00', '2023-04-20 12:00:00', 'IDK', 'Mars', 3, 1, 1, 0),
(12, '2023-04-20 21:37:00', '2023-04-20 22:38:00', 'bv', 'vcbcv', 1, 1, 0, 1),
(13, '2023-04-20 21:37:00', '2023-04-20 22:38:00', 'fghfghfgh', 'vbnvcbn', 3, 1, 0, 1),
(14, '2023-04-20 21:51:00', '2023-04-20 22:52:00', 'WIsh me luck', 'Amsterdam', 2, 1, 0, 1),
(15, '2023-04-20 21:58:00', '2023-04-20 22:59:00', 'help', 'amsterdam', 2, 2, 0, 1),
(16, '2023-04-21 22:15:00', '2023-04-21 23:16:00', 'lol', 'amsterdam', 2, 1, 0, 1),
(17, '2023-04-20 22:36:00', '2023-04-20 23:38:00', 'fghfg', 'noord', 2, 1, 0, 1),
(18, '2023-04-20 22:40:00', '2023-04-20 23:41:00', 'wow', 'wowwwwwww', 1, 1, 0, 1);

CREATE TABLE `melding_instructeur` (
  `melding_id` int(11) NOT NULL,
  `instructeur_id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `verzender` varchar(255) NOT NULL,
  `inhoud` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `melding_klant` (
  `melding_id` int(11) NOT NULL,
  `gebruikers_id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `verzender` varchar(255) NOT NULL,
  `inhoud` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `planned_lessons` (
  `id` int(11) NOT NULL,
  `lesson_id` int(11) NOT NULL,
  `instructor_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `planned_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `rijschoolhouder` (
  `eigenaar_id` int(11) NOT NULL,
  `admin_naam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `rijschoolhouder` (`eigenaar_id`, `admin_naam`, `email`, `wachtwoord`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin');

CREATE TABLE `ziekmelding` (
  `ziekmelding_id` int(11) NOT NULL,
  `instructeur_id` int(11) NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


ALTER TABLE `auto`
  ADD PRIMARY KEY (`auto_id`);

ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `les_id` (`les_id`,`instructeur_id`,`gebruikers_id`),
  ADD KEY `instructeur_id` (`instructeur_id`),
  ADD KEY `gebruikers_id` (`gebruikers_id`);

ALTER TABLE `instructeur`
  ADD PRIMARY KEY (`instructeur_id`),
  ADD KEY `fk_auto_instructeur` (`auto_id`);

ALTER TABLE `leerlingen`
  ADD PRIMARY KEY (`gebruikers_id`);

ALTER TABLE `lessen`
  ADD PRIMARY KEY (`les_id`),
  ADD KEY `instructeur_id` (`instructeur_id`),
  ADD KEY `gebruikers_id` (`gebruikers_id`),
  ADD KEY `auto_id` (`auto_id`);

ALTER TABLE `melding_instructeur`
  ADD PRIMARY KEY (`melding_id`),
  ADD KEY `instructeur_id` (`instructeur_id`);

ALTER TABLE `melding_klant`
  ADD PRIMARY KEY (`melding_id`),
  ADD KEY `gebruikers_id` (`gebruikers_id`);

ALTER TABLE `planned_lessons`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_planned_lessons_lesson_id` (`lesson_id`),
  ADD KEY `fk_planned_lessons_instructor_id` (`instructor_id`),
  ADD KEY `fk_planned_lessons_student_id` (`student_id`);

ALTER TABLE `rijschoolhouder`
  ADD PRIMARY KEY (`eigenaar_id`);


ALTER TABLE `auto`
  MODIFY `auto_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

ALTER TABLE `instructeur`
  MODIFY `instructeur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `leerlingen`
  MODIFY `gebruikers_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

ALTER TABLE `lessen`
  MODIFY `les_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

ALTER TABLE `melding_instructeur`
  MODIFY `melding_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `melding_klant`
  MODIFY `melding_id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `planned_lessons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

ALTER TABLE `rijschoolhouder`
  MODIFY `eigenaar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`les_id`) REFERENCES `lessen` (`les_id`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`instructeur_id`) REFERENCES `instructeur` (`instructeur_id`),
  ADD CONSTRAINT `feedback_ibfk_3` FOREIGN KEY (`gebruikers_id`) REFERENCES `leerlingen` (`gebruikers_id`);

ALTER TABLE `instructeur`
  ADD CONSTRAINT `fk_auto_instructeur` FOREIGN KEY (`auto_id`) REFERENCES `auto` (`auto_id`);

ALTER TABLE `lessen`
  ADD CONSTRAINT `lessen_ibfk_1` FOREIGN KEY (`instructeur_id`) REFERENCES `instructeur` (`instructeur_id`),
  ADD CONSTRAINT `lessen_ibfk_2` FOREIGN KEY (`gebruikers_id`) REFERENCES `leerlingen` (`gebruikers_id`);

ALTER TABLE `melding_instructeur`
  ADD CONSTRAINT `melding_instructeur_ibfk_1` FOREIGN KEY (`instructeur_id`) REFERENCES `instructeur` (`instructeur_id`);

ALTER TABLE `melding_klant`
  ADD CONSTRAINT `melding_klant_ibfk_1` FOREIGN KEY (`gebruikers_id`) REFERENCES `leerlingen` (`gebruikers_id`);

ALTER TABLE `planned_lessons`
  ADD CONSTRAINT `fk_planned_lessons_instructor_id` FOREIGN KEY (`instructor_id`) REFERENCES `instructeur` (`instructeur_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_planned_lessons_lesson_id` FOREIGN KEY (`lesson_id`) REFERENCES `lessen` (`les_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_planned_lessons_student_id` FOREIGN KEY (`student_id`) REFERENCES `leerlingen` (`gebruikers_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
