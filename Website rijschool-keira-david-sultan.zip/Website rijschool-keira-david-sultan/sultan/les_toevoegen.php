<?php
include 'db.php';
$db = new Database();

session_start();
// als de gebruiker niet bestaat in de session wordt hij terug gestuurd naar de begin pagina

if (!isset($_SESSION['email'])) {
    header("Location:index.php");
}


// hier wordt gecheckt of er gebruik is gemaakt van de request method post

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // De post waarden worden hier gezet met behulp van placeholders om sql injecties te voorkomen

    try {
        $sql = "INSERT INTO les_gegevens (les_id, leerling_id, instructeur_id, geplande_datum, geplande_tijd, ophaal_adres, les_doel, commentaar) VALUES (:les_id, :leerling_id, :instructeur_id,  :geplande_datum, :geplande_tijd, :ophaal_adres, :les_doel, :commentaar)";
        $placeholders = [
            'les_id' => null,
            'leerling_id' => $_POST['leerling_id'],
            'instructeur_id' => $_POST['instructeur_id'],
            'geplande_datum' => $_POST['geplande_datum'],
            'geplande_tijd' => $_POST['geplande_tijd'],
            'ophaal_adres' => $_POST['ophaal_adres'],
            'les_doel' => $_POST['les_doel'],
            'commentaar' => $_POST['commentaar'],

        ];

        // hier worden de waardes door middel van queries in de database gezet

        $db->insert($sql, $placeholders);
        echo "<script>alert('Inserted successfully')</script>";
    } catch (\Exception $e) {
        echo $e->getMessage();
    }
}
$sqlles = "SELECT les_gegevens.*, leerling_gegevens.naam AS leerling_naam, instructeur_gegevens.voornaam AS instructeur_voornaam FROM les_gegevens JOIN leerling_gegevens ON les_gegevens.leerling_id = leerling_gegevens.leerling_id JOIN instructeur_gegevens ON les_gegevens.instructeur_id = instructeur_gegevens.instructeur_id";
$result = $db->select($sqlles);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto </title>\
    <link rel="stylesheet" href="toevoegen_style.css" />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
      integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;600&display=swap"
    />
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#">Auto</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link mr-2" href="alle_res.php">Alle Reserveringen</a>
            </li>
            <li class="nav-item">
                <a class="nav-link mr-2" href="res_vandaag.php">Reserveringen Vandaag</a>
            </li>
            <li class="nav-item">
                <a class="nav-link mr-2" href="select_date.php">Maak Reservering</a>
            </li>
            <li class="nav-item">
                <a class="nav-link mr-2" href="klanten.php">Klanten</a>
            </li>
            <li class="nav-item">
                <a class="nav-link mr-2" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

    <div class="container-fluid h-100">
        <div class="row justify-content-center align-items-center h-100">
            <div class="col col-sm-6 col-md-6 col-lg-4 col-xl-3">
                <div class="form-group">
                    <h1 class="display-4">Voeg les toe</h1><br>
                    <form method="POST" enctype="multipart/form-data">

                        <select name="leerling_id" class="form-control form-control-lg">
                            <option value="">Selecteer leerling</option>
                            <?php
                            $sql = "SELECT * FROM leerling_gegevens";
                            $leerlingen = $db->select($sql);
                            if (!is_null($leerlingen)) {
                                foreach ($leerlingen as $leerling) {
                                    echo '<option value="' . $leerling['leerling_id'] . '">' . $leerling['naam'] . '</option>';
                                }
                            }
                            ?>
                        </select>

                        <select name="instructeur_id" class="form-control form-control-lg">
                            <option value="">Selecteer instructeur</option>
                            <?php
                            $sql = "SELECT * FROM instructeur_gegevens";
                            $instructeurs = $db->select($sql);
                            if (!is_null($instructeurs)) {
                                foreach ($instructeurs as $instructeur) {
                                    echo '<option value="' . $instructeur['instructeur_id'] . '">' . $instructeur['voornaam'] . '</option>';
                                }
                            }
                            ?>
                        </select>
                        <input type="date" name="geplande_datum" placeholder="geplande_datum" value="" min="2023-04-18" max="2030-12-31" class="form-control form-control-lg" required><br>
                        <input type="time" name="geplande_tijd" placeholder="geplande_tijd" value="" class="form-control form-control-lg" required><br>

                        <input type="text" name="ophaal_adres" placeholder="ophaal_adres" value="" class="form-control form-control-lg" required><br>

                        <input type="text" name="les_doel" placeholder="les_doel" value="" class="form-control form-control-lg" required><br>

                        <input type="text" name="commentaar" placeholder="commentaar" value="" class="form-control form-control-lg" optional><br>

                        <button type="submit" class="btn btn-primary btn-lg btn-block">Voeg les toe</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <h1>Alle lessen</h1>
<table class="table table-striped">
    <tr>
        <th>les_id</th>
        <th>leerling_naam</th>
        <th>instructeur_voornaam</th>
        <th>geplande_datum</th>
        <th>geplande_tijd</th>
        <th>ophaal_adres</th>
        <th>les_doel</th>
        <th>commentaar</th>
    </tr>
    <?php
    if (!is_null($result)) {
        foreach ($result as $rows) { ?>
            <tr>
                <td><?php echo $rows['les_id'] ?></td>
                <td><?php echo $rows['leerling_naam'] ?></td>
                <td><?php echo $rows['instructeur_voornaam'] ?></td>
                <td><?php echo $rows['geplande_datum'] ?></td>
                <td><?php echo $rows['geplande_tijd'] ?></td>
                <td><?php echo $rows['ophaal_adres'] ?></td>
                <td><?php echo $rows['les_doel'] ?></td>
                <td><?php echo $rows['commentaar'] ?></td>
            </tr>
    <?php }
    } ?>

</table>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper-base.min.js" integrity="sha384-+JZJzJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQ" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-0mSbJDEHial+2LbL4pHzpMz9P4ViZOGmI6OtK5X7zzTtmIaKl8WvA8bJRUs9HdJh" crossorigin="anonymous"></script>
<br><br>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper-base.min.js" integrity="sha384-+JZJzJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQJQ" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-0mSbJDEHial+2LbL4pHzpMz9P4ViZOGmI6OtK5X7zzTtmIaKl8WvA8bJRUs9HdJh" crossorigin="anonymous"></script>
</body>

</html>