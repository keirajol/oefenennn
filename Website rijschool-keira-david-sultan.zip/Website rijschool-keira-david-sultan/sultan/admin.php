<?php
session_start();

// Check if the user is logged in and has admin role, if not redirect to login page
if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin') {
    header("location: login.php");
    exit;
}

echo "Welcome to the admin dashboard, " . $_SESSION["email"] . "!";

// Check if the form was submitted
if (isset($_POST['submit'])) {
    // Get the title and content from the form
    $voorwaarden = $_POST['voorwaarden'];

    // Create connection to the database
    $conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");
    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare and execute the query to insert the new row into the "algemene_voorwaarden" table
    $query = "INSERT INTO algemene_voorwaarden (voorwaarden, datum) VALUES ('$voorwaarden', NOW())";
    if (mysqli_query($conn, $query)) {
        // Row added successfully
        echo "Row added successfully.";
    } else {
        // Error adding row
        echo "Error adding row: " . mysqli_error($conn);
    }

    // Close the connection
    mysqli_close($conn);

    // Check if the form was submitted
    if (isset($_POST['assign_car'])) {
        // Get the instructor id and car id from the form
        $instructeur_id = $_POST['instructeur_id'];
        $auto_id = $_POST['auto_id'];

        // Create connection to the database
        $conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");

        // Check if the connection was successful
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        // Prepare and execute the query to update the "instructeur" table with the assigned car
        $query = "UPDATE instructeur SET auto_id = $auto_id WHERE instructeur_id = $instructeur_id";
        if (mysqli_query($conn, $query))
            // Instructor updated successfully
            echo "Instructor updated successfully.";
    } else {
        // Error updating instructor
        echo "Error updating instructor: " . mysqli_error($conn);
    }

    // Close the connection
    mysqli_close($conn);
}

?>

<!DOCTYPE html>
<html>

<head>
    <title>Add Voorwaarden and Assign Car to Instructor</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
</head>

<body>
    <h2>Add Voorwaarden</h2>
    <form action="" method="POST">
        <label for="voorwaarden">Voorwaarden:</label>
        <textarea id="voorwaarden" name="voorwaarden" required></textarea><br><br>
        <input type="submit" name="submit" value="Add Voorwaarden">
    </form>


    <h1>Assign a Car to an Instructor</h1>

    <!-- Add a logout button -->
    <a href='logout.php'>Logout</a>

    <!-- Add a link to the register page -->
    <a href='../david/instructeur_register.david.php'>Register Instructor</a>

    <!-- Add a form to assign a car to an instructor -->
    <form method='POST' action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>'>
        <label for='instructeur_id'>Instructor:</label>
        <select id='instructeur_id' name='instructeur_id' required>
            <option value=''>Select an instructor</option>
            <?php
            // Create connection to the database
            $conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");

            // Check if the connection was successful
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Retrieve the list of instructors from the database and display them in a dropdown menu
            $query = "SELECT * FROM instructeur";
            $result = mysqli_query($conn, $query);
            while ($row = mysqli_fetch_assoc($result))
                echo "<option value='" . $row['instructeur_id'] . "'>" . $row['naam'] . "</option>";
            // Close the connection
            mysqli_close($conn);
            ?>
        </select>

        <label for='auto_id'>Car:</label>
        <select id='auto_id' name='auto_id' required>
            <option value=''>Select a car</option>
            <?php
            // Create connection to the database
            $conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");

            // Check if the connection was successful
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }

            // Retrieve the list of cars from the database and display them in a dropdown men
            $query = "SELECT * FROM auto";
            $result = mysqli_query($conn, $query);
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<option value='" . $row['auto_id'] . "'>" . $row['merk'] . " " . $row['brandstof_type'] . " " . $row['klaar_om_te_rijden'] . " (" . $row['beschrijving'] . ")</option>";
            }
            // Check if the form was submitted
if (isset($_POST['assign_car'])) {
    // Get the instructor id and car id from the form
    $instructeur_id = $_POST['instructeur_id'];
    $auto_id = $_POST['auto_id'];

    // Create connection to the database
    $conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");

    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare and execute the query to update the "instructeur" table with the assigned car
    $query = "UPDATE instructeur SET auto_id = $auto_id WHERE instructeur_id = $instructeur_id";
    if (mysqli_query($conn, $query))
        // Instructor updated successfully
        echo "Instructor updated successfully.";
} else {
    // Error updating instructor
    echo "Error updating instructor: " . mysqli_error($conn);
}


            // Close the connection
            mysqli_close($conn);
            ?>
        </select>

        <input type='submit' name='assign_car' value='Assign Car'>
    </form>
</body>

</html>