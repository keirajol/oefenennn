<?php
session_start();

// Create connection to the database
$conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");
// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Prepare and execute the query to retrieve the rows from the "algemene_voorwaarden" table
$query = "SELECT voorwaarden, datum FROM algemene_voorwaarden ORDER BY datum DESC";
$result = mysqli_query($conn, $query);

// Display the rows in a table
echo "<h2>Algemene Voorwaarden</h2>";
echo "<table>";
echo "<tr><th>Voorwaarden</th><th>Datum</th></tr>";
while($row = mysqli_fetch_assoc($result)){
    echo "<tr><td>" . $row['voorwaarden'] . "</td><td>" . $row['datum'] . "</td></tr>";
}
echo "</table>";

// Close the connection
mysqli_close($conn);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
    <style>
        .table-container {
  max-width: 100%;
  overflow-x: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 1rem;
}

th,
td {
  padding: 0.5rem;
  text-align: left;
  vertical-align: top;
  border: 1px solid #ddd;
}

th {
  background-color: #f2f2f2;
  font-weight: bold;
}

tr:nth-child(even) {
  background-color: #f2f2f2;
}

@media only screen and (max-width: 600px) {
  table {
    font-size: 0.8rem;
  }

  th,
  td {
    padding: 0.3rem;
  }
}
    </style>
</head>
<body>
<div class="table-container">
    <tbody>
      <?php
      while($row = mysqli_fetch_assoc($result)){
        echo "<tr><td>" . $row['voorwaarden'] . "</td><td>" . $row['datum'] . "</td></tr>";
      }
      ?>
    </tbody>
  </table>
</div>
</body>
</html>