<?php
session_start();

// Check if the user is logged in and has admin role, if not redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin'){
    header("location: login.php");
    exit;
}

// Create connection to the database
$conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form was submitted
if(isset($_POST['submit'])){
    // Get the form data
    $naam = $_POST['naam'];
    $email = $_POST['email'];
    $wachtwoord = $_POST['wachtwoord'];

    // Prepare and execute the query to insert the new instructor
    $query = "INSERT INTO instructeur (naam, email, wachtwoord) VALUES ('$naam', '$email', '$wachtwoord')";
    $result = mysqli_query($conn, $query);

    // Check if the query was successful
    if($result){
        // Registration successful
        echo "Instructor registered successfully.";
    } else{
        // Registration failed
        echo "Error: " . mysqli_error($conn);
    }
}

// Close the connection
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register Instructor</title>
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
</head>
<body>
    <h2>Register Instructor</h2>
    <form method="POST" action="">
        <input type="text" name="naam" placeholder="naam" required><br><br>
        <input type="email" name="email" placeholder="Email" required><br><br>
        <input type="password" name="wachtwoord" placeholder="Wachtwoord" required><br><br>
        <input type="submit" name="submit" value="Register">
    </form>
</body>
</html>