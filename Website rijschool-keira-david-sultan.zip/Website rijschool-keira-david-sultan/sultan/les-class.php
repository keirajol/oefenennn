<?php
// Set the database credentials
$db_host = "localhost";
$db_name = "autorijschool_vierkante_wielen";
$db_user = "root";
$db_pass = "";

// Create a new PDO connection
try {
  $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
  die("Failed to connect to the database: " . $e->getMessage());
}


function createLesson($pdo, $student_name, $lesson_subject, $lesson_date, $lesson_start_time, $lesson_end_time, $additional_notes) {
    // Validate the input data
    if (empty($student_name)) {
      throw new Exception("Student name cannot be empty");
    }
    if (empty($lesson_subject)) {
      throw new Exception("Lesson subject cannot be empty");
    }
    if (empty($lesson_date)) {
      throw new Exception("Lesson date cannot be empty");
    }
    if (empty($lesson_start_time)) {
      throw new Exception("Lesson start time cannot be empty");
    }
    if (empty($lesson_end_time)) {
      throw new Exception("Lesson end time cannot be empty");
    }
  
    // Verify that the input data matches the expected data types and formats
    $date_regex = "/^\d{4}-\d{2}-\d{2}$/";
    $time_regex = "/^\d{2}:\d{2}$/";
    if (!preg_match($date_regex, $lesson_date)) {
      throw new Exception("Invalid lesson date format");
    }
    if (!preg_match($time_regex, $lesson_start_time)) {
      throw new Exception("Invalid lesson start time format");
    }
    if (!preg_match($time_regex, $lesson_end_time)) {
      throw new Exception("Invalid lesson end time format");
    }
  
    // Insert the new lesson data into the database
    try {
      $stmt = $pdo->prepare("INSERT INTO lessons (student_name, lesson_subject, lesson_date, lesson_start_time, lesson_end_time, additional_notes) VALUES (?, ?, ?, ?, ?, ?)");
      $stmt->execute([$student_name, $lesson_subject, $lesson_date, $lesson_start_time, $lesson_end_time, $additional_notes]);
      echo "Lesson created successfully!";
    } catch(PDOException $e) {
      throw new Exception("Error creating lesson: " . $e->getMessage());
    }
  }

// Check if the create lesson form has been submitted
if (isset($_POST['create_lesson'])) {
    $student_name = $_POST['student_name'];
    $lesson_subject = $_POST['lesson_subject'];
    $lesson_date = $_POST['lesson_date'];
    $lesson_start_time = $_POST['lesson_start_time'];
    $lesson_end_time = $_POST['lesson_end_time'];
    $additional_notes = $_POST['additional_notes'];
  
    try {
      createLesson($pdo, $student_name, $lesson_subject, $lesson_date, $lesson_start_time, $lesson_end_time, $additional_notes);
    } catch(Exception $e) {
      echo "Error: " . $e->getMessage();
    }
  }

?>

<form action="create_lesson.php" method="POST">
  <label for="student_name">Student Name:</label>
  <input type="text" id="student_name" name="student_name" required><br><br>

  <label for="lesson_subject">Lesson Subject:</label>
  <input type="text" id="lesson_subject" name="lesson_subject" required><br><br>

  <label for="lesson_date">Lesson Date:</label>
  <input type="date" id="lesson_date" name="lesson_date" required><br><br>

  <label for="lesson_start_time">Start Time:</label>
  <input type="time" id="lesson_start_time" name="lesson_start_time" required><br><br>

  <label for="lesson_end_time">End Time:</label>
  <input type="time" id="lesson_end_time" name="lesson_end_time" required><br><br>

  <label for="additional_notes">Additional Notes:</label>
  <textarea id="additional_notes" name="additional_notes"></textarea><br><br>

  <<input type="submit" name="create_lesson" value="Create Lesson">
</form>

