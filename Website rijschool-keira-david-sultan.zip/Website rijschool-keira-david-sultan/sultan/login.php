<?php
session_start();
if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    //Create connection to the database
    $conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");
    //Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    //Prepare and execute the query
    $query = "SELECT * FROM rijschoolhouder WHERE email='$email' AND wachtwoord='$password'";
    $result = mysqli_query($conn, $query);
    //Check if the query returned a result
    if(mysqli_num_rows($result) > 0){
        //Login successful
        $_SESSION['loggedin'] = true;
        $_SESSION['email'] = $email;
        $_SESSION['role'] = 'admin';
        header("location: admin.php");
    } else{
        //Login failed
        echo "<p class='error'>Login failed. Invalid email or password.</p>";
    }
    //Close the connection
    mysqli_close($conn);
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            padding: 30px;
            width: 400px;
            max-width: 90%;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            font-weight: bold;
            margin-bottom: 10px;
        }
        input[type="email"], input[type="password"] {
            padding: 10px;
            border-radius: 5px;
            border: none;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
        }
        input[type="submit"] {
            background-color: blue;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #3e8e41;
        }
        .error {
            color: red;
            text-align: center;
            margin-top: 20px;
        }
        /* Media queries for mobile devices */
        @media only screen and (max-width: 600px) {
            .card {
                width: 90%;
                padding: 20px;
            }
            input[type="email"], input[type="password"], input[type="submit"] {
                padding: 8px;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h2>Login Page rijschoolhouder</h2>
            <form method="POST" action="">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" required>
                <label for="password">Password:</label>
                <input type="password" name="password" id="password" required>
                <input type="submit" name="submit" value="Login">
            </form>
            <?php if(isset($_POST['submit']) && mysqli_num_rows($result) == 0) { ?>
                <p class="error">Login failed. Invalid email or password.</p>
            <?php } ?>
        </div>
    </div>
</body>
</html>