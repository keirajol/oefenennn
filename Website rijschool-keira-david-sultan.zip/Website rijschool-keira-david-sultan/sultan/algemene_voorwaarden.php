<?php
session_start();

// Check if the user is logged in and has admin role, if not redirect to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true || $_SESSION["role"] !== 'admin'){
    
    exit;
}

// Check if the form was submitted
if(isset($_POST['submit'])){
    // Get the title and content from the form
    $voorwaarden = $_POST['voorwaarden'];

    // Create connection to the database
    $conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");
    // Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare and execute the query to insert the new row into the "algemene_voorwaarden" table
    $query = "INSERT INTO algemene_voorwaarden (voorwaarden, datum) VALUES ('$voorwaarden', NOW())";
    if(mysqli_query($conn, $query)){
        // Row added successfully
        echo "Row added successfully.";
    } else{
        // Error adding row
        echo "Error adding row: " . mysqli_error($conn);
    }

    // Close the connection
    mysqli_close($conn);
}

?>
