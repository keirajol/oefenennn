<?php
session_start();
if(isset($_POST['submit'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    //Create connection to the database
    $conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");
    //Check if the connection was successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
    //Prepare and execute the query
    $query = "SELECT * FROM instructeur WHERE email='$email' AND wachtwoord='$password'";
    $result = mysqli_query($conn, $query);
    //Check if the query returned a result
    if(mysqli_num_rows($result) > 0){
        //Login successful
        $row = mysqli_fetch_assoc($result);
        $_SESSION['loggedin'] = true;
        $_SESSION["user_id"] = $row["instructeur_id"];
        $_SESSION['email'] = $email;
        $_SESSION['role'] = 'instructor';
        header("location: instructor.php");
    } else{
        //Login failed
        echo "Login failed. Invalid email or password.";
    }
    //Close the connection
    mysqli_close($conn);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Instructor Login Page</title>
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
</head>
<body>
    <h2>Instructor Login Page</h2>
    <form method="POST" action="">
        <input type="email" name="email" placeholder="Email" required><br><br>
        <input type="password" name="password" placeholder="Password" required><br><br>
        <input type="submit" name="submit" value="Login">
    </form>
</body>
</html>