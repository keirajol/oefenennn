<?php
//Hello future person! my name is david and I wrote this file
//and now I will guide you through what I have done here
//
//Function index:
//
//PDO connection, line                                           19-45
//db_activate (how i run most statements), line                  47-52
//login method (instructeur), line                               58-81
//My regex for determening if an email is valid or not, line     83-91
//my method used for detecting Email duplicates, line            94-107
//my default hash method, line                                   109-113
//this is how i count messages, line                             116-123
//My way of seeing if the user is logged in, line                125-130

session_start();

class Database
{

    public $host;
    public $db;
    public $user;
    public $pass;
    public $charset;
    public $pdo;

    public function __construct()
    {

        $this->host = "127.0.0.1";
        $this->db = "autorijschool_vierkante_wielen";
        $this->user = "root";
        $this->pass = "";
        $this->charset = "utf8mb4";

        try {

            $dsn = "mysql:host=$this->host;dbname=$this->db;charset=$this->charset";
            $options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false,];
            $this->pdo = new PDO($dsn, $this->user, $this->pass, $options);
        } catch (\PDOException $e) {
            throw new \PDOException($e->getMessage(), (int) $e->getCode());
        }
    }

    public function db_activate(string $query, array $placeholders)
    {
        $statement = $this->pdo->prepare($query);
        $statement->execute($placeholders);

    }





    public function login(string $email, string $password)
    {
        $statement = $this->pdo->prepare("SELECT * FROM instructeur WHERE email = :user_email");
        $statement->bindParam(":user_email", $email);
        $statement->execute();
        $result = $statement->fetch();

        if ($result == TRUE) {

            if (password_verify($password, $result['wachtwoord'])) {
                echo "login sucsessfull";
                $_SESSION["user_id"] = $result['instructeur_id'];
                $_SESSION["user_name"] = $result['naam'];
                $_SESSION["email_adress"] = $result['email'];
                $_SESSION["password"] = $password;
                header('location: instructeur_page.php');
            } else {
                echo "incorrect password";
            }

        } else {
            echo "login faillure";
        }
    }

    public function email_regex(string $email)
    {
        $pattern = "/.+\@.+\..+/i";
        if (preg_match($pattern, $email)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }


    public function email_duplicate_detector(string $email)
    {

        $statement = $this->pdo->query("SELECT email FROM instructeur WHERE email='$email'");
        $replica_detection = $statement->rowCount();

        if ($replica_detection > 0) {
            return 'TRUE';
        } elseif ($replica_detection == 0) {
            return 'FALSE';
        } {
            return 'whoopsie something somewhere whent wrong somehow';
        }
    }

    public function default_hash(string $password)
    {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        return $hashed_password;
    }


    public function count_messages($instructeur_id)
    {

        $statement = $this->pdo->prepare("SELECT * FROM melding_instructeur WHERE instructeur_id = '$instructeur_id'");
        $statement->execute();
        return $statement->fetchAll();

    }

    public function login_check()
    {
        if (!isset($_SESSION["user_id"])) {
            header('location: instructeur_login.php');
        }
    }

}