<?php
//Hello again Future person. me am David. And i'll explain what's going on here in this file
// on line 14-16 I retreve the notifications
// And the main part is on line 55-83. This is where everything happens


require 'Database.class.david.php';
$method = new Database();

$method->login_check();

$user_id = $_SESSION['user_id'];

$statement = $method->pdo->prepare("SELECT * FROM melding_instructeur WHERE instructeur_id = '$user_id'");
$statement->execute();
$result = $statement->fetchAll();

?>



<head>
    <link rel="stylesheet" href="allincompasingstylesheet.css">
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif"
        sizes="16x16">
    <title>
        meldingen
    </title>
</head>


<body>
    <script src="https://kit.fontawesome.com/da462c9a4b.js" crossorigin="anonymous"></script>

    <div class="header">
        <div class="logoName">
            <img src="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" alt="Logo" width="70px">
            <h1>AVW</h1>
        </div>

        <h1>instructeur pagina</h1>

        <div class="logoutAndName">
            <h1>Meldingen</h1>
            <a href="logout.php">logout</a>
        </div>

    </div>

    </br>
    </br>
    </br>

    <?php
    foreach ($result as $row) {
        ?>

        <div class="alert_box">
            <div class="alert_item">

                <div class="dates">
                    <p>
                        <?php echo $row['verzender'] ?>
                    </p>
                    <p>
                        <?php echo $row['datum'] ?>
                    </p>
                    <a href="instructeur_melding_delete.php?melding_id= <?php echo $row['melding_id'] ?>"><i
                            class="fa-solid fa-trash"></i></a>
                </div>

                <div class="contents">
                    <p>
                        <?php echo $row['inhoud'] ?>
                    </p>
                </div>
            </div>
        </div>



        <?php
    }
    ?>

    <a class="wideButton" href="instructeur_page.php">trug</a>


    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>

    <div class="footer">
        <table>
            <tr>
                <td> </td>
                <td> </td>
                <td> </td>
            </tr>
            <tr>
                <th><img src="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" alt="Logo" width="70px">
                </th>
                <th>
                    <h1>service</h1>
                </th>
                <th>
                    <h1>profiel</h1>
                </th>
            </tr>
            <tr>
                <td>
                    <p id="slogan">goedkoop, snel </br> & professioneel</p>
                </td>
                <td>
                    <p>algemene voorwaarden</p>
                </td>
                <td>
                    <p>andere dingen</p>
                </td>
            </tr>
            <tr>
            <tr>
                <td> </td>
                <td>
                    <p>contract info</p>
                </td>
                <td>
                    <p>stuur serviceklacht</p>
                </td>
            </tr>
            <td>
                <p><i class="fa-solid fa-envelope"></i>AVW@rijschool.nl</p>
            </td>
            <td>
                <p>facatures & cursussen</p>
            </td>
            <td><a href="les_toevoegen_instructeur.php">Les inplannen<a></td>
            </tr>
            <tr>
                <td>
                    <p><i class="fa-solid fa-house"></i>Rijschool Baas 64</p>
                </td>
                <td>
                    <p>nog een</p>
                </td>
                <td>
                    <p>profiel info</p>
                </td>
            </tr>
            <tr>
                <td>
                    <p><i class="fa-solid fa-phone"></i>060-314-1592</p>
                </td>
                <td>
                    <p>footer element</p>
                </td>
                <td><a href="logout.php">logout</a></td>
            </tr>
            <tr>
                <td> </td>
                <td> </td>
                <td> </td>
            </tr>
        </table>

        <iframe id="maponfooter" src="https://maps.google.com/maps?q=Rijschool Baas&output=embed"></iframe>



    </div>

</body>