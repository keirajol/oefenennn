<?php
//this deletes a notification and immediately sends you back to the notification page
require 'Database.class.david.php';
$method = new Database();

if (!isset($_SESSION["user_id"])) {
    header('location: instructeur_login.php');
}

if (isset($_GET['melding_id'])) {

    $sql = "DELETE FROM melding_instructeur WHERE melding_id = :id";
    $placeholders = ['id' => $_GET['melding_id']];
    $method->db_activate($sql, $placeholders);
    header('location: instructeur_meldingen.php');
} else {
    header('location: instructeur_meldingen.php');
}


?>