<?php
require 'Database.class.david.php';
$method = new Database();


$statement = $method->pdo->prepare('SELECT * FROM auto');
$statement->execute();
$result = $statement->fetchAll();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>wagenlijst</title>
    <style> 
    .wagenlijst {
        border-collapse: collapse;
        width: 100%;
    }
    .wagenlijst td, th {
        border: 1px solid #ddd;
        padding: 8px;
    }
    .wagenlijst th {
        text-align: left;
        background-color: #428af5;
        color: white;
    }
    .wagenlijst_button {
        text-decoration: none;
        text-align: center;
    }
    .wagenlijst_text {
        position: relative;
    }
    .textarea {
        display: flex;
        width: 100%;
        border: none;
    }
    </style>
</head>
<body>


<table class="wagenlijst">
<tr>
    <th>id</th>
    <th>merk</th>
    <th>brandstof</th>
    <th>functioneel</th>
    <th>beschrijving</th>
    <th colspan="2">functionalitijd</th>
</tr>
<?php foreach ($result as $data) { 
    
if ($data['klaar_om_te_rijden'] == 1) {
    $functional = "hij doet het";
} else {
    $functional = "hij is stuk";
}

?>

    <tr>
        <td><?php echo $data['auto_id']; ?></td>
        <td><?php echo $data['merk']; ?></td>
        <td><?php echo $data['brandstof_type']; ?></td>
        <td><?php echo $functional ?></td>
        <td class="wagenlijst_text"><textarea class="textarea"><?php echo $data['beschrijving']; ?></textarea></td>
        <td><p>Verwijder</p></td>

    </tr>

<?php } ?>

</table>



</body>
</html>