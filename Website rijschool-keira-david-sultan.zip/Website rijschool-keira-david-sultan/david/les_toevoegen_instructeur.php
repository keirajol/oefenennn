<?php

//Hi there, hello! I'm david once again. I have not written this code. The credit is for sultan who sent it to me
//And i just made it's style the same as other files. The comments you see below are from Sultan

require 'Database.class.david.php';
$method = new Database();
$today = date("Y") . "-" . date('m') . "-" . date('d');
// Check if the user is logged in and has instructor role, if not redirect to login page

$method->login_check();


// Create connection to the database
$conn = mysqli_connect("localhost", "root", "", "autorijschool_vierkante_wielen");
// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get the instructor id from the session
$instructeur_id = $_SESSION["user_id"];



?>


<?php
// Display the form for planning a lesson
?>

<head>
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif"
        sizes="16x16">
    <title>
        les planning
    </title>
    <style>
        a {
            text-decoration: none;
            color: black;
            transition: color 0.3s ease;
        }

        a:hover {
            text-decoration: none;
            color: #0074bc;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            padding: 30px;
            width: 400px;
            max-width: 90%;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 10px;
        }

        input,
        select,
        textarea {
            padding: 10px;
            border-radius: 5px;
            border: none;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
        }

        input[type="submit"],
        input[type="button"] {
            background-color: #0074bc;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #3e8e41;
        }

        .error {
            color: red;
            text-align: center;
            margin-top: 20px;
        }

        /* Media queries for mobile devices */
        @media only screen and (max-width: 600px) {
            .card {
                width: 90%;
                padding: 20px;
            }

            input[type="email"],
            input[type="password"],
            input[type="submit"] {
                padding: 8px;
                margin-bottom: 10px;
            }
        }

        a {
            text-decoration: none;
            color: black;
            transition: color 0.3s ease;
        }

        a:hover {
            text-decoration: none;
            color: #0074bc;
        }
    </style>
</head>

<body>




    <div class="container">
        <div class="card">
            <h2>Plan een les in</h2>
            <form method="POST" action="">
                <select id='student_id' name='student_id' required>
                    <?php
                    $query = "SELECT gebruikers_id, gebruikersnaam FROM leerlingen";
                    $result = mysqli_query($conn, $query);
                    echo "<option value='' selected disabled>Leerling</option>";
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value='" . $row["gebruikers_id"] . "'>" . $row["gebruikersnaam"] . "</option>";
                    }
                    ?>

                </select><br>


                <input type='date' id='lesson_date' name='lesson_date' required><br>

                <label for='lesson_start'>Start Tijd:</label>
                <input type='time' id='lesson_start' name='lesson_start' required><br>

                <label for='lesson_end'>Eind Tijd:</label>
                <input type='time' id='lesson_end' name='lesson_end' required><br>

                <select name="goal" required>
                    <option value="" selected disabled>Doel van les</option>
                    <option value="proefles">Proefles</option>
                    <option value="rijles">Rijles</option>
                    <option value="herexamen">Herexamen</option>
                    <option value="tussentijdsetoets">Tussentijdse toets</option>
                </select>

                <input type='text' id='pickup_location' name='pickup_location' required
                    placeholder="Ophaal locatie"><br>


                <textarea id='discription' name='comment' placeholder="routebescrijving (optioneel)"></textarea><br>



                <input type='submit' name='submit' value='Plan het in'>
                <a href="instructeur_page.php">terug</a>
            </form>

        </div>
    </div>








    <?php
    // Handle form submission
    if (isset($_POST["submit"])) {


        $message_planning = "Uw les staat ingepland voor" . $_POST["lesson_date"];
        $statement = "INSERT INTO melding_instructeur (instructeur_id, datum, verzender, inhoud) 
        VALUES (:id, :date, 'AVW', :message)";
        $placeholders = ['id' => $_SESSION["user_id"], 'date' => $today, 'message' => $message_planning];
        $method->db_activate($statement, $placeholders);



        // Get form data
        $student_id = $_POST["student_id"];
        $lesson_date = $_POST["lesson_date"];
        $lesson_start = $_POST["lesson_start"];
        $lesson_end = $_POST["lesson_end"];
        $goal = $_POST["goal"];
        $pickup_location = $_POST["pickup_location"];
        $instructeur_id = $_SESSION["user_id"];
        $routDiscription = $_POST["comment"];


        // Insert new lesson into the database
        $query = "INSERT INTO lessen (gebruikers_id, instructeur_id,     datum,         lestijd_start,   lestijd_eind, doel_van_les, ophaal_locatie,      locatie_beschrijving) 
                        VALUES ('$student_id', '$instructeur_id', '$lesson_date', '$lesson_start', '$lesson_end', '$goal',      '$pickup_location', '$routDiscription')";
        $result = mysqli_query($conn, $query);


    
        if ($result) {
            // Display success message
            echo "<div class='success'>Lesson planned successfully.</div>";
            // header("location: instructeur_page.php");
        } else {
            // Display error message
            echo "<div class='error'>Error planning lesson: " . mysqli_error($conn) . "</div>";
        }
    }



    // Close the connection
    mysqli_close($conn);

    ?>
</body>

<!-- Sultan -->