<?php
//It is I. David. I'm once again returning to you to explain this file you are currently readung through
//feature index:.
//
//getting current date, line 20
//my triple inner join for 'dagrooster' 32-36
//displaying the users name line 67
//the notification link 'meldingen voor instructeur', line 75-84
//'dagrooster', line  91-151
//
//if nothing appears on the 'dagrooster' it means that there are no lessons with today's date in the database. add a new lesson to see it in action. (click 'Les inplannen' in the footer)
//
//'dagrooster uitprinten', line 196
//'les toevoegen', line 205
//'ziekmelden', line 214
//logout, line 223

require 'Database.class.david.php';
$method = new Database();
$today = date("Y") . "-" . date('m') . "-" . date('d');

$method->login_check();

$user_id = $_SESSION['user_id'];

$sql = $method->pdo->prepare("SELECT * FROM melding_instructeur WHERE instructeur_id = '$user_id'");
$sql->execute();
$messages = $sql->fetchAll();



$statement = $method->pdo->prepare("SELECT lessen.*, leerlingen.gebruikersnaam, instructeur.naam FROM ((lessen
INNER JOIN leerlingen ON lessen.gebruikers_id = leerlingen.gebruikers_id)
INNER JOIN instructeur ON lessen.instructeur_id = instructeur.instructeur_id) WHERE datum = '$today';");
$statement->execute();
$result = $statement->fetchAll();

?>

<head>

    <head>
        <link rel="stylesheet" href="allincompasingstylesheet.css">
        <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif"
            sizes="16x16">
        <title>
            instructeur
        </title>
    </head>


<body>
    <script src="https://kit.fontawesome.com/da462c9a4b.js" crossorigin="anonymous"></script>



    <div class="header">
        <div class="logoName">
            <img src="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" alt="Logo" width="70px">
            <h1>AVW</h1>
        </div>

        <h1>instructeur pagina</h1>

        <div class="logoutAndName">
            <h1>
                <?php echo $_SESSION["user_name"] ?>
            </h1>
            <a href="logout.php">logout</a>
        </div>

    </div>


    <div class="notify">
        <a href="instructeur_meldingen.php" text-decoration='none'>
            <div class="notifications">
                <i class="fa-solid fa-message"></i>
                <p>
                    <?php echo count($messages); ?>
                </p>
            </div>
        </a>
    </div>


    </br>



    <div class="allcontent">

        <div class="daylist">

            <div class="titlediv">
                <h2>Dagrooster
                    <?php echo $today ?>
                </h2>
            </div>


            <?php
            foreach ($result as $events_of_today) {
                if ($events_of_today['instructeur_id'] == $user_id) {
                    ?>


                    <div class="item_of_today">

                        <div class="content1">
                            <p>
                                <?php echo $events_of_today["doel_van_les"] ?>
                            </p>
                            <p>leerling:
                                <?php echo $events_of_today['gebruikersnaam'] ?>
                            </p>
                            <p>instructor:
                                <?php echo $events_of_today['naam'] ?>
                            </p>
                            <p>van
                                <?php echo $events_of_today['lestijd_start'] ?> tot
                                <?php echo $events_of_today['lestijd_eind'] ?>
                            </p>
                        </div>

                        <div class="content2">
                            <div class="content-row-1">
                                <p id="textarea_daylist">
                                    <?php echo $events_of_today['locatie_beschrijving'] ?>
                                </p>
                            </div>
                            <div class="content-row-2">
                                <iframe id="maponlist"
                                    src="https://maps.google.com/maps?q=<?php echo $events_of_today['ophaal_locatie'] ?>&output=embed"></iframe>
                            </div>
                        </div>

                    </div>

                    <?php
                }
            }
            ?>
            <div class="titlediv">
                <h2>Dagrooster
                    <?php echo $today ?>
                </h2>
            </div>

        </div>
    </div>

    </br>
    </br>
    </br>
    </br>
    </br>
    </br>
    </br>

    <div class="footer">
        <table>
            <tr>
                <td> </td>
                <td> </td>
                <td> </td>
            </tr>
            <tr>
                <th><img src="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" alt="Logo" width="70px">
                </th>
                <th>
                    <h1>service</h1>
                </th>
                <th>
                    <h1>profiel</h1>
                </th>
            </tr>
            <tr>
                <td>
                    <p id="slogan">goedkoop, snel </br> & professioneel</p>
                </td>
                <td>
                    <p>algemene voorwaarden</p>
                </td>
                <td>
                    <p>andere dingen</p>
                </td>
            </tr>
            <tr>
            <tr>
                <td> </td>
                <td>
                    <p>contract info</p>
                </td>
                <td>
                    <p onClick="window.print()" class="print-link">Dagrooster uitprinten</p>
                </td>
            </tr>
            <td>
                <p><i class="fa-solid fa-envelope"></i>AVW@rijschool.nl</p>
            </td>
            <td>
                <p>facatures & cursussen</p>
            </td>
            <td><a href="les_toevoegen_instructeur.php" class="print-link">Les inplannen<a></td>
            </tr>
            <tr>
                <td>
                    <p><i class="fa-solid fa-house"></i>Rijschool Baas 64</p>
                </td>
                <td>
                    <p>David was hier</p>
                </td>
                <td><a href="ziek.php" class="print-link">meld je ziek</a></td>
            </tr>
            <tr>
                <td>
                    <p><i class="fa-solid fa-phone"></i>060-314-1592</p>
                </td>
                <td>
                    <p> </p>
                </td>
                <td><a href="logout.php">logout</a></td>
            </tr>
            <tr>
                <td> </td>
                <td> </td>
                <td> </td>
            </tr>
        </table>

        <iframe id="maponfooter" src="https://maps.google.com/maps?q=Rijschool Baas&output=embed"></iframe>

    </div>

</body>