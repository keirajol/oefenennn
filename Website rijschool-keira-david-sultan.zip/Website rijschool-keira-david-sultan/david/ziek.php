<?php
//Greetings. it mne. david
// this file just has one input and two INSERT queries.
// on line 16-18 is the query that puts an entry into the 'melding_instructeur' table
//and on line 20-24 is a query that adds an entry into 'ziekmelding'
//and that's about it for this file.

require 'Database.class.david.php';
$method = new Database();
$today = date("Y") . "-" . date('m') . "-" . date('d');
$who_is_sick = $_SESSION['user_id'];

$method->login_check();

if (isset($_POST['datum'])) {
    $statement = 'INSERT INTO ziekmelding (instructeur_id, datum) VALUES (:id, :date)';
    $placeholders = ['id' => $who_is_sick, 'date' => $_POST['datum']];
    $method->db_activate($statement, $placeholders);

    $sick_date = "U bent ziek gemeld op " . $_POST['datum'];
    $statement = "INSERT INTO melding_instructeur (instructeur_id, datum, verzender, inhoud) 
    VALUES (:id, :date, 'AVW', :message)";
    $placeholders = ['id' => $who_is_sick, 'date' => $today, 'message' => $sick_date];
    $method->db_activate($statement, $placeholders);
    header('location: instructeur_page.php');
}
?>

<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            padding: 30px;
            width: 400px;
            max-width: 90%;
        }

        h2 {
            text-align: center;
            margin-bottom: 30px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 10px;
        }

        input[type="email"],
        input[type="password"],
        input[type="date"] {
            padding: 10px;
            border-radius: 5px;
            border: none;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
        }

        input[type="submit"],
        input[type="button"] {
            background-color: #0074bc;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #3e8e41;
        }

        .error {
            color: red;
            text-align: center;
            margin-top: 20px;
        }

        /* Media queries for mobile devices */
        @media only screen and (max-width: 600px) {
            .card {
                width: 90%;
                padding: 20px;
            }

            input[type="email"],
            input[type="password"],
            input[type="submit"] {
                padding: 8px;
                margin-bottom: 10px;
            }
        }

        a {
            text-decoration: none;
            color: black;
            transition: color 0.3s ease;
        }

        a:hover {
            text-decoration: none;
            color: #0074bc;
        }
    </style>
</head>

<body>


    <div class="container">
        <div class="card">
            <h2>Wanneer wilt u zich ziekmelden?</h2>
            <form method="POST" action="ziek.php">
                <input type="date" name="datum" min="<?php echo $today ?>"></input>
                <input type="submit" value="meld je ziek"></input>
                </br>
                <a href="instructeur_page.php">annuleren</a>
            </form>
        </div>
    </div>








</body>