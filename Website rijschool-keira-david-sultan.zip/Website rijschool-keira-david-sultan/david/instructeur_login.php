<?php

//hello again future person. It is me david and i will now explain some things. As you can see this is the login page for the instructors
//nothing really notable about this page. The only thing worth mentioning is that I got the css from Sultan
require 'Database.class.david.php';
$method = new Database();

if (isset($_POST['email'])) {
    
    $email_verification = $method->email_regex($_POST['email']);
    if ($email_verification == TRUE) {
        $method->login($_POST['email'], $_POST['password']);
    } else {
        $_SESSION['message_in_input'] = "Invalid E-mail adress";
    }


}

if (!isset($_SESSION['message_in_input'])) {
    $_SESSION['message_in_input'] = "E-mail adress";
} 
if (!isset($_SESSION['message_in_input_pass'])) {
    $_SESSION['message_in_input_pass'] = "Wachtwoord";
}

?>


<head>
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16"> 
    <title>
        inloggen
    </title>
</head>


    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            padding: 30px;
            width: 400px;
            max-width: 90%;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            font-weight: bold;
            margin-bottom: 10px;
        }
        input[type="email"], input[type="password"] {
            padding: 10px;
            border-radius: 5px;
            border: none;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
        }
        input[type="submit"] {
            background-color: #0074bc;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        input[type="submit"]:hover {
            background-color: #3e8e41;
        }
        .error {
            color: red;
            text-align: center;
            margin-top: 20px;
        }
        /* Media queries for mobile devices */
        @media only screen and (max-width: 600px) {
            .card {
                width: 90%;
                padding: 20px;
            }
            input[type="email"], input[type="password"], input[type="submit"] {
                padding: 8px;
                margin-bottom: 10px;
            }
        }
    </style>



</head>
<body>
    <div class="container">
        <div class="card">
            <h2>Inloggen instructeur</h2>

                <form action="instructeur_login.php" method="post">
                <input type="email" name="email" id="email" placeholder="<?php echo $_SESSION['message_in_input'] ?>"></input>
                <input type="password" name="password" id="password" placeholder="Wachtwoord"></input>
                <input type="submit" value="login"></input>
                </form>
           
        </div>
    </div>
</body>
</html>