<?php
require 'Database.class.david.php';
$method = new Database();

if (isset($_POST['email'])) {

    $email_verification = $method->email_regex($_POST['email']);
    if ($email_verification == TRUE) {
        
            $possible_duplicate_email = $method->email_duplicate_detector($_POST['email']);
            
            if ($possible_duplicate_email == 'TRUE') {
                echo "email taken. pick another";
            } elseif ($possible_duplicate_email == 'FALSE') {
                $hashed_password = $method->default_hash($_POST['password']);
                $statement = "INSERT INTO instructeur (naam, email, wachtwoord) VALUES (:name_form, :email_form, :password_form)";
                $placeholders = ['name_form' => $_POST['name'], 'email_form' => $_POST['email'],'password_form' => $hashed_password];
                $method->db_activate($statement, $placeholders);
                header("location: ../sultan/admin.php");
                
            }else {
                echo "error?";
            }

    } else {
        echo "invalid email";
    }

}


?>


<form action="instructeur_register.david.php" method="POST">
<input type="text" placeholder="naam" name="name"></input>
<input type="text" placeholder="E-mail adress" name="email"></input>
<input type="text" placeholder="wachtwoord" name="password"></input>
<input type="submit" value="registreer instructeur"></input>
</form>

