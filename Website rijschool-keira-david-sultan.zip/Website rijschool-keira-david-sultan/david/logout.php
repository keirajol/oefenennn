<?php
//not much to see here. but it does the job
require 'Database.class.david.php';
session_destroy();
header('location: ../Home/home.php');