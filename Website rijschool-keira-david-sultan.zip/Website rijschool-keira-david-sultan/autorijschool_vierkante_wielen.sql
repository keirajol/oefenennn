-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 20 apr 2023 om 15:43
-- Serverversie: 10.4.28-MariaDB
-- PHP-versie: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `autorijschool_vierkante_wielen`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `algemene_voorwaarden`
--

CREATE TABLE `algemene_voorwaarden` (
  `Voorwaarden_ID` int(11) NOT NULL,
  `Voorwaarden` varchar(255) DEFAULT NULL,
  `Datum` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `algemene_voorwaarden`
--

INSERT INTO `algemene_voorwaarden` (`Voorwaarden_ID`, `Voorwaarden`, `Datum`) VALUES
(0, 'ewfasdcwe', '2023-04-20'),
(0, 'algemene voorwaarden', '2023-04-20'),
(0, 'fytg', '2023-04-20');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `auto`
--

CREATE TABLE `auto` (
  `auto_id` int(11) NOT NULL,
  `merk` varchar(255) NOT NULL,
  `brandstof_type` varchar(255) NOT NULL,
  `klaar_om_te_rijden` tinyint(1) NOT NULL,
  `beschrijving` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `auto`
--

INSERT INTO `auto` (`auto_id`, `merk`, `brandstof_type`, `klaar_om_te_rijden`, `beschrijving`) VALUES
(1, 'audi', 'gas', 1, 'elektrisch'),
(2, 'lambo', 'diesel', 1, 'yes'),
(3, 'Fiat', 'gas', 1, 'oke');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `feedback`
--

CREATE TABLE `feedback` (
  `feedback_id` int(11) NOT NULL,
  `les_id` int(11) NOT NULL,
  `instructeur_id` int(11) NOT NULL,
  `gebruikers_id` int(11) NOT NULL,
  `inhoud` varchar(255) NOT NULL,
  `post_datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `instructeur`
--

CREATE TABLE `instructeur` (
  `instructeur_id` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(256) NOT NULL,
  `auto_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `instructeur`
--

INSERT INTO `instructeur` (`instructeur_id`, `naam`, `email`, `wachtwoord`, `auto_id`) VALUES
(2, 'keira', 'keiranaz1@icloud.com', '$2y$10$A/RYFq0hTq.rKyYFdgGczuUBa3xFHjYy7Q5wOlojzXSzCI6xbaPUq', 2),
(3, 'david', 'david@hotmail.com', '$2y$10$CjoPvSI2P2.CyPUhYRY5O..rxiM6Fc4BgqLMnrR2Y3XWHArHTcGza', 1),
(4, 'sultan', 'sultan@hotmail.com', 'sultan', 3),
(7, 'os', 'os@gmail.com', '$2y$10$FXBWew07Du888GCemO6AkO9VT34suoohXmVGdJS/M9mcMfk8LvFzS', 1);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `leerlingen`
--

CREATE TABLE `leerlingen` (
  `gebruikers_id` int(11) NOT NULL,
  `gebruikersnaam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `leerlingen`
--

INSERT INTO `leerlingen` (`gebruikers_id`, `gebruikersnaam`, `email`, `wachtwoord`) VALUES
(10, 'keira', 'keiranaz1@icloud.com', '$2y$10$SE6ndU/KvOAyhsqnMstro.dshESK2eAakNTc6hVKRctpRYMCFjD.i'),
(13, 'sultan', 'sultan@hotmail.com', '$2y$10$6kmVzLNUWoUK57EpknQn9ONEkTDWNJA5ZTmHp6j6ANCWl.cMw7wVa'),
(14, 'jeff', 'jeff@hotmail.com', '$2y$10$pHJZ3WlO5hEIDBDXI6iEd.0tBiomANgPBg.TJ9E0knNTqo.FAZttu'),
(17, 'apgar', 'apgar@icloud.com', '$2y$10$Q9jCdFa5kpV7srMM0ODkuORcIXTl8rQxiODTQ.Wk8IoOvkCMqGy.K'),
(20, 'walter', 'walter@gmail.com', '$2y$10$6i9FXWZYesd6gNb9EWBbduX9WW4K5J9mLbb6l/OAnHyRCyMSb4g36'),
(21, 'soof', 'soof@gmail.com', '$2y$10$YWTLbnVtvXjhYb8vvROJKujTlK72/60cQWfS.klnS8RkBWBVkI6i2'),
(22, 'joep', 'joep@hotmail.com', '$2y$10$dxVaVK0NAy/x4bnc.Tpy9OF09tan7LzBT9q8YJv0kihQqmKCcsD6K');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `lessen`
--

CREATE TABLE `lessen` (
  `les_id` int(11) NOT NULL,
  `lestijd_start` time NOT NULL,
  `lestijd_eind` time NOT NULL,
  `doel_van_les` varchar(255) NOT NULL,
  `ophaal_locatie` varchar(255) NOT NULL,
  `gebruikers_id` int(11) DEFAULT NULL,
  `instructeur_id` int(11) NOT NULL,
  `datum` date DEFAULT NULL,
  `locatie_beschrijving` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `lessen`
--

INSERT INTO `lessen` (`les_id`, `lestijd_start`, `lestijd_eind`, `doel_van_les`, `ophaal_locatie`, `gebruikers_id`, `instructeur_id`, `datum`, `locatie_beschrijving`) VALUES
(42, '09:55:00', '10:55:00', 'rijles', 'dvsgv', 13, 2, '2023-04-29', NULL),
(44, '10:28:00', '11:28:00', 'proefles', 'm,', 14, 2, '2023-04-28', NULL),
(45, '14:55:00', '15:55:00', 'rijles', 'gfbv', 10, 3, '2023-04-29', NULL),
(59, '15:17:00', '16:17:00', 'tussentijdsetoets', 'dgx', 10, 2, '2023-04-21', NULL),
(69, '16:32:00', '16:32:00', 'herexamen', 'qwd', 21, 2, '2023-04-20', 'London'),
(70, '16:33:00', '17:33:00', 'proefles', 'London', 22, 2, '2023-04-20', '');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `melding_instructeur`
--

CREATE TABLE `melding_instructeur` (
  `melding_id` int(11) NOT NULL,
  `instructeur_id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `verzender` varchar(255) NOT NULL,
  `inhoud` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `melding_instructeur`
--

INSERT INTO `melding_instructeur` (`melding_id`, `instructeur_id`, `datum`, `verzender`, `inhoud`) VALUES
(12, 2, '2023-04-20', 'AVW', 'U bent ziek gemeld op 2023-04-23'),
(13, 2, '2023-04-20', 'AVW', 'Uw les staat ingepland voor2023-04-21'),
(14, 2, '2023-04-20', 'AVW', 'Uw les staat ingepland voor2023-04-20'),
(15, 2, '2023-04-20', 'AVW', 'Uw les staat ingepland voor2023-04-20');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `melding_klant`
--

CREATE TABLE `melding_klant` (
  `melding_id` int(11) NOT NULL,
  `gebruikers_id` int(11) NOT NULL,
  `datum` date NOT NULL,
  `verzender` varchar(255) NOT NULL,
  `inhoud` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `melding_klant`
--

INSERT INTO `melding_klant` (`melding_id`, `gebruikers_id`, `datum`, `verzender`, `inhoud`) VALUES
(1, 10, '2023-04-20', 'leff', 'ik ben ziek');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `rijschoolhouder`
--

CREATE TABLE `rijschoolhouder` (
  `eigenaar_id` int(11) NOT NULL,
  `admin_naam` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `wachtwoord` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `rijschoolhouder`
--

INSERT INTO `rijschoolhouder` (`eigenaar_id`, `admin_naam`, `email`, `wachtwoord`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `ziekmelding`
--

CREATE TABLE `ziekmelding` (
  `ziekmelding_id` int(11) NOT NULL,
  `instructeur_id` int(11) NOT NULL,
  `datum` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `ziekmelding`
--

INSERT INTO `ziekmelding` (`ziekmelding_id`, `instructeur_id`, `datum`) VALUES
(1, 2, '2023-04-21'),
(2, 2, '2023-04-28'),
(3, 2, '2023-04-23');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `auto`
--
ALTER TABLE `auto`
  ADD PRIMARY KEY (`auto_id`);

--
-- Indexen voor tabel `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feedback_id`),
  ADD KEY `les_id` (`les_id`,`instructeur_id`,`gebruikers_id`),
  ADD KEY `instructeur_id` (`instructeur_id`),
  ADD KEY `gebruikers_id` (`gebruikers_id`);

--
-- Indexen voor tabel `instructeur`
--
ALTER TABLE `instructeur`
  ADD PRIMARY KEY (`instructeur_id`),
  ADD KEY `auto_id` (`auto_id`);

--
-- Indexen voor tabel `leerlingen`
--
ALTER TABLE `leerlingen`
  ADD PRIMARY KEY (`gebruikers_id`);

--
-- Indexen voor tabel `lessen`
--
ALTER TABLE `lessen`
  ADD PRIMARY KEY (`les_id`),
  ADD KEY `instructeur_id` (`instructeur_id`),
  ADD KEY `gebruikers_id` (`gebruikers_id`);

--
-- Indexen voor tabel `melding_instructeur`
--
ALTER TABLE `melding_instructeur`
  ADD PRIMARY KEY (`melding_id`),
  ADD KEY `instructeur_id` (`instructeur_id`);

--
-- Indexen voor tabel `melding_klant`
--
ALTER TABLE `melding_klant`
  ADD PRIMARY KEY (`melding_id`),
  ADD KEY `gebruikers_id` (`gebruikers_id`);

--
-- Indexen voor tabel `rijschoolhouder`
--
ALTER TABLE `rijschoolhouder`
  ADD PRIMARY KEY (`eigenaar_id`);

--
-- Indexen voor tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  ADD PRIMARY KEY (`ziekmelding_id`),
  ADD KEY `instructeur_id` (`instructeur_id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `auto`
--
ALTER TABLE `auto`
  MODIFY `auto_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT voor een tabel `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `instructeur`
--
ALTER TABLE `instructeur`
  MODIFY `instructeur_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT voor een tabel `leerlingen`
--
ALTER TABLE `leerlingen`
  MODIFY `gebruikers_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT voor een tabel `lessen`
--
ALTER TABLE `lessen`
  MODIFY `les_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT voor een tabel `melding_instructeur`
--
ALTER TABLE `melding_instructeur`
  MODIFY `melding_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT voor een tabel `melding_klant`
--
ALTER TABLE `melding_klant`
  MODIFY `melding_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `rijschoolhouder`
--
ALTER TABLE `rijschoolhouder`
  MODIFY `eigenaar_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  MODIFY `ziekmelding_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `feedback`
--
ALTER TABLE `feedback`
  ADD CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`les_id`) REFERENCES `lessen` (`les_id`),
  ADD CONSTRAINT `feedback_ibfk_2` FOREIGN KEY (`instructeur_id`) REFERENCES `instructeur` (`instructeur_id`),
  ADD CONSTRAINT `feedback_ibfk_3` FOREIGN KEY (`gebruikers_id`) REFERENCES `leerlingen` (`gebruikers_id`);

--
-- Beperkingen voor tabel `instructeur`
--
ALTER TABLE `instructeur`
  ADD CONSTRAINT `instructeur_ibfk_1` FOREIGN KEY (`auto_id`) REFERENCES `auto` (`auto_id`);

--
-- Beperkingen voor tabel `lessen`
--
ALTER TABLE `lessen`
  ADD CONSTRAINT `lessen_ibfk_1` FOREIGN KEY (`instructeur_id`) REFERENCES `instructeur` (`instructeur_id`),
  ADD CONSTRAINT `lessen_ibfk_2` FOREIGN KEY (`gebruikers_id`) REFERENCES `leerlingen` (`gebruikers_id`);

--
-- Beperkingen voor tabel `melding_instructeur`
--
ALTER TABLE `melding_instructeur`
  ADD CONSTRAINT `melding_instructeur_ibfk_1` FOREIGN KEY (`instructeur_id`) REFERENCES `instructeur` (`instructeur_id`);

--
-- Beperkingen voor tabel `melding_klant`
--
ALTER TABLE `melding_klant`
  ADD CONSTRAINT `melding_klant_ibfk_1` FOREIGN KEY (`gebruikers_id`) REFERENCES `leerlingen` (`gebruikers_id`);

--
-- Beperkingen voor tabel `ziekmelding`
--
ALTER TABLE `ziekmelding`
  ADD CONSTRAINT `ziekmelding_ibfk_1` FOREIGN KEY (`instructeur_id`) REFERENCES `instructeur` (`instructeur_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
