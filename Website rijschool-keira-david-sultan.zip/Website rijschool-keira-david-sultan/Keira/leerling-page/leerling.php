
<html>
<head>
    <title>Leerling pagina</title>
<link href="../../Home/index.css" rel="stylesheet">
<link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
</head>

<body>

<div class="navbar">
            <img src="../IMG/L-logo-2.png" alt="Logo" width="70px">
                <!-- Deze a zorgt ervoor dat je uit kan loggen. -->
            <a href="../logout/logout.php">uitloggen</a>   
<?php
// Hier zorg ik ervoor dat je de naam ziet als je ingelogd bent als een speciefieke user
session_start();
if (isset($_SESSION['username'])) {?>
<div class="email"><?php echo $_SESSION['username']; ?></div><?php } ?>
</div>
 
 <?php 
 // Hier roep ik de de pagina aan waar je lessen kan toevoegen die vervolgens geprint worden en je kan ze verwijderen
include '../les-toevoegen-printen/lessen-print.php';
// Hier roep ik de meldingen aan de meldingen heeft david gemaakt
include '../meldingen/leerling_meldingen.php';
?>

<a href="https://www.google.com/maps/place/Rijschool+Baas/@52.3447872,4.9088012,17.15z/data=!4m14!1m7!3m6!1s0x47c6098754f2bb11:0x2df0f60a7b61ed63!2sRijschool+Baas!8m2!3d52.3448173!4d4.9104269!16s%2Fg%2F1thw1byk!3m5!1s0x47c6098754f2bb11:0x2df0f60a7b61ed63!8m2!3d52.3448173!4d4.9104269!16s%2Fg%2F1thw1byk">Vierkante wielen<br>
                    Pauwenlaan 69 <br>
                    1392 NA Amsterdam
</a>
</body>
</html>
<!-- Keira Jol -->

