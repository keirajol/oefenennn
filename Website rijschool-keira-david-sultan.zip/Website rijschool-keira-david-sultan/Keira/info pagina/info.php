<?php
// Hier zorg ik ervoor dat alle instructeurs en de rijschoolhouder opgehaald worden uit de database om ze vervolgens later op deze pagina te posten
include '../Database/db.php';
$database = new Database();

$statement = $database->pdo->query("SELECT* FROM rijschoolhouder");
$rijschool = $statement->fetchAll(PDO::FETCH_ASSOC);
$stmt = $database->pdo->query("SELECT * FROM instructeur");
$instructors = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>

<head>
    <title>Info</title>
    <link href="../../Home/index.css" rel="stylesheet">
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
</head>

<body>
    <div class="content">
        <div class="navbar">
            <img src="../IMG/L-logo-2.png" alt="Logo" width="70px">
            <div class="menu-icon">
                <button><i class="fa fa-bars"></i></button>
            </div>
            <div class="locations">
                <a href="../../Home/home.php">Home</a>
                <a href="#">Informatie</a>
                <a href="../Registreren/registreren-form.php">Registreren</a>
                <a href="../Login-leerling/login-form.php">Inloggen</a>
                <a href="">Contact</a>
            </div>
        </div>
        <div class="rijschool">
            <h1>Eigenaar rijschool:</h1>
            <!-- Hier zorg ik ervoor dat de rijschoolhouder en instructeurs gepost worden en als ze in de databse veranderen dat het hier ook aangepast word. -->
            <?php foreach ($rijschool as $rijschoolhouder): ?>
                <h2>
                    <?php echo $rijschoolhouder['admin_naam']; ?>
                </h2>
                <br>
                <a href="#">
                    <?php echo $rijschoolhouder['email']; ?>
                </a>
            <?php endforeach; ?>
        </div>
        <div class="instructeur">
            <h1>Instructeurs</h1>
            <?php foreach ($instructors as $instructor): ?>
                <h2>
                    <?php echo $instructor['naam']; ?>
                </h2>
                <br>
                <a href="#">
                    <?php echo $instructor['email']; ?>
                </a>
            <?php endforeach; ?>
        </div>
        <div>
            <p>Wij zijn een rijschool die vooral gefocust is op mensen met een beperking. Wij beschikken over speciale auto's die speciaal naar jouw instellingen zijn ingesteld. Wij hebben een van de hoogste slagingspercentages van Nederland en daar zijn we heel trots op. Schrijf je nu in voor een proefles voor maar €60. </p>
            <br>
            <a href="../Registreren/registreren-form.php"><button class="button-1">Meld je nu aan!</button></a>

        </div>
    </div>
    <div class="footer">
    <div class="footer-row-1">
            <a href="../../Home/home.php">Home</a>
                <a href="../info pagina/info.php">Informatie</a>
                <a href="../Registreren/registreren-form.php">Registreren</a>
                <a href="../Login-leerling/login-form.php">Inloggen</a>
                <a href="#">Contact</a>
                <a href="../../sultan/voorwaarden.php">Algemene voorwaarden</a>
            </div>
            <div class="footer-row-2">
                <a href="https://www.google.com/maps/place/Rijschool+Baas/@52.3447872,4.9088012,17.15z/data=!4m14!1m7!3m6!1s0x47c6098754f2bb11:0x2df0f60a7b61ed63!2sRijschool+Baas!8m2!3d52.3448173!4d4.9104269!16s%2Fg%2F1thw1byk!3m5!1s0x47c6098754f2bb11:0x2df0f60a7b61ed63!8m2!3d52.3448173!4d4.9104269!16s%2Fg%2F1thw1byk">Vierkante wielen<br>
                    Pauwenlaan 69 <br>
                    1392 NA Amsterdam
                    </p>
            </div>
            <div class="footer-row-3">
                <a href="../david/instructeur_login.php">Inloggen instructeur</a><br>
                <a href="../sultan/login.php">Rijschoolhouder</a>

            </div>
        </div>
</body>

</html>
<!-- Keira Jol -->