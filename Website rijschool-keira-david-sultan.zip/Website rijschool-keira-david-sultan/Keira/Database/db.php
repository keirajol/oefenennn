<?php
// Mijn database connectie
class Database
{
    public $host;
    public $db;
    public $user;
    public $pass;
    public $charset;
    public $pdo;

    public function __construct()
    {

        $this->host = "127.0.0.1";
        $this->db = "autorijschool_vierkante_wielen";
        $this->user = "root";
        $this->pass = "";
        $this->charset = "utf8mb4";

        try {

            $dsn = "mysql:host=$this->host;dbname=$this->db;charset=$this->charset";
            $options = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false,];
            $this->pdo = new PDO($dsn, $this->user, $this->pass, $options);
        } catch (\PDOException $e) {
            throw new \PDOException($e->getMessage(), (int) $e->getCode());
        }
    }
    

       // Functie om lessen te kunnen verwijderen
    public function delete($query,$data) {
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($data);
    }

    public function db_activate(string $query, array $placeholders)
    {
        $statement = $this->pdo->prepare($query);
        $statement->execute($placeholders);

    }

}
?>
<!-- Keira Jol -->