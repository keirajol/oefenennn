<?php
// Hier zorg ik ervoor dat als je op logout drukt in leerling.php dat je uitgelogd word. 
session_destroy();
header("Location: ../../Home/home.php");
exit();
// Keira Jol
?>
