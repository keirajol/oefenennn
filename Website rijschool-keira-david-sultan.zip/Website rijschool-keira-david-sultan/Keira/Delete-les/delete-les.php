<?php
// Hier zorg ik ervoor dat ik lessen kan verwijderen
    include '../Database/db.php';
    $database = new Database();

    $les_id = $_GET['les_id'];
    if($les_id) {
    try {
        // Mijn query om lessen te verwijderen
        $query = "DELETE FROM lessen where les_id=:les_id";
        $data = [
            'les_id' => $les_id
        ];
                // Hier roep ik de functie op om lessen te verwijderen
        $database->delete($query,$data);
        header("Location: ../leerling-page/leerling.php");
    } catch (\Exception $e) { 
        echo $e->getMessage();
    }
}
?>
<!-- Keira Jol -->