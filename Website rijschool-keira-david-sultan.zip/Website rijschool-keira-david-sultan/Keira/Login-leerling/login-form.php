<html>
<!-- Form om inte loggen als leerling -->
<head>
    <title>login</title>
    <link href="index.css" rel="stylesheet">
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
    <style>
          body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            padding: 30px;
            width: 400px;
            max-width: 90%;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            font-weight: bold;
            margin-bottom: 10px;
        }
        .email {
            padding: 10px;
            border-radius: 5px;
            border: none;
            box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 20px;
        }

        /* Media queries for mobile devices */
        @media only screen and (max-width: 600px) {
            .card {
                width: 90%;
                padding: 20px;
            }
            input[type="email"], input[type="password"], input[type="submit"] {
                padding: 8px;
                margin-bottom: 10px;
            }
        }
    </style>
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
        <h2>Inloggen leerlingen</h2>
        <form method="post" action="login.php" class="login-form">
            <label for="email">Email:</label>
            <input  class="email" type="text" id="username" name="email" required><br><br>
            <label for="wachtwoord">Wachtwoord:</label>
            <input class="email" type="password" id="password" name="wachtwoord" required><br><br>
            <input class="button" type="submit" name="submit" value="Inloggen">
        </form>
        </div>
    </div>

</body>
</html>
<!-- Keira Jol -->