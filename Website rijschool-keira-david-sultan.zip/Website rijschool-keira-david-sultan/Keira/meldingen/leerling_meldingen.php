<?php


$user_id = $_SESSION['gebruikers_id']; //change this into the session later

$statement = $database->pdo->prepare("SELECT * FROM melding_klant WHERE gebruikers_id = '$user_id'");
$statement->execute();
$result = $statement->fetchAll();

// echo count($result);

?>


<head>
    <title>Meldingen</title>
<link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
<style>
.alert_box {
    display: flex;
    flex-direction: row;
}    
.alert_item {
    background-color: rgb(243, 243, 243);
    height: fit-content;
    display: flex;
    flex-direction: column;
    width: 100%;
}
.dates {
    /* background-color: aqua; */
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 5px 20px 5px 20px;
    background-color: rgb(210, 209, 209);
}
.dates img {
    height: 30px;
    padding-top: 9px;
}
.contents {
    display: flex;
    flex-direction: row;
justify-content: center;
    align-items: center;
    padding-left: 9px;
}
.delete_button {
    background-color: rgb(223, 223, 223);
}

</style>
</head>


<body>
<?php 
foreach ($result as $row) {
?>

<div class="alert_box">
    <div class="alert_item">

        <div class="dates">
            <p><?php echo $row['verzender'] ?></p>
            <p><?php echo $row['datum'] ?></p>
            <a href="leerling_melding_delete.php?melding_id= <?php echo $row['melding_id']?>"><img src="https://cdn-icons-png.flaticon.com/512/3405/3405244.png"></a>
        </div>

        <div class="contents">
            <p><?php echo $row['inhoud'] ?></p>
        </div>
    </div> 
</div>



<?php
} 
?>


</body>

