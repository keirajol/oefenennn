<?php
require '../Database/db.php';

$database = new Database();

if (isset($_GET['melding_id'])) {

    $sql = "DELETE FROM melding_klant WHERE melding_id = :id";
    $placeholders = ['id' => $_GET['melding_id']];
    $database->db_activate($sql, $placeholders);
    header('location: leerling_meldingen.php');
} else {
    header('location: leerling_meldingen.php');
}


?>