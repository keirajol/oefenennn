<!DOCTYPE html>
<html>

<head>
    <title>Registratie</title>
    <link href="index.css" rel="stylesheet">
    <link rel="icon" href="https://www.autosturm.nl/content/uploads/2019/09/logo_big.png" type="image/gif" sizes="16x16">
</head>
<!-- Formulie om je te registreren als leerling -->
<body class="registreren">
    <h1>Registratie leerlingen</h1>
    <form action="registreren.php" method="post" class="register-form">
        <label for="gebruikersnaam">Gebruikersnaam:</label>
        <input type="text" name="gebruikersnaam" id="gebruikersnaam" required><br><br>

        <label for="email">E-mail:</label>
        <input type="email" name="email" id="email" required><br><br>

        <label for="wachtwoord">Wachtwoord:</label>
        <input type="password" name="wachtwoord" id="wachtwoord" required><br><br>
        <input class="button" type="submit" name="submit" value="Registreren">
    </form>
</body>

</html>
<!-- Keira Jol -->