<?php
require '../Database/db.php';
$database = new Database();

if (isset($_POST['submit'])) {
    $username = $_POST['gebruikersnaam'];
    $email = $_POST['email'];
    $password = $_POST['wachtwoord'];
// Dit is mijn query om leerlingen toe te voegen aan database bij leerlingen
    $query = "INSERT INTO leerlingen (gebruikersnaam, email, wachtwoord) VALUES (:gebruikersnaam, :email, :wachtwoord)";
    $stmt = $database->pdo->prepare($query);
    $stmt->bindParam(':gebruikersnaam', $username);
    $stmt->bindParam(':email', $email);
    // Hier word de password gehased in de database
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    $stmt->bindParam(':wachtwoord', $hashedPassword);

    if ($stmt->execute()) {
        // Als het goed gaat wordt je terug gestuurd naar de home om vervolgens in te loggen
        header("Location: ../../Home/home.php");
        exit();
    } else {
        // Als het mis gaat wordt dit geprint
        echo "Er is iets fout gegaan bij het registreren";
    }
}
?>

<!-- Keira Jol -->