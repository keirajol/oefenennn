<!DOCTYPE html>
<html>

<head>
    <title>
        Home
    </title>
    <link href="index.css" rel="stylesheet">
</head>

<body>
    <div class="content">
        <div class="navbar">
            <img src="../Keira/IMG/L-logo-2.png" alt="Logo" width="70px">
            <div class="locations">
            <a href="#">Home</a>
                <a href="../Keira/info pagina/info.php">Informatie</a>
                <a href="../Keira/Registreren/registreren-form.php">Registreren</a>
                <a href="../Keira/Login-leerling/login-form.php">Inloggen</a>
                <a href="">Contact</a>
            </div>
        </div>
        <div class="body">
            <div class="first-row">

                <div class="tekst">
                    <h2>Vierkante wielen</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                        laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in
                        voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat
                        non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                    <a href="../Keira/info pagina/info.php"><button class="button-1">Informatie</button></a>
                </div>
            </div>
        </div>
        <div class="footer">
            <div class="footer-row-1">
            <a href="#">Home</a>
                <a href="../Keira/info pagina/info.php">Informatie</a>
                <a href="../Keira/Registreren/registreren-form.php">Registreren</a>
                <a href="../Keira/Login-leerling/login-form.php">Inloggen</a>
                <a href="#">Contact</a>
                <a href="../sultan/voorwaarden.php">Algemene voorwaarden</a>
            </div>
            <div class="footer-row-2">
                <a href="https://www.google.com/maps/place/Rijschool+Baas/@52.3447872,4.9088012,17.15z/data=!4m14!1m7!3m6!1s0x47c6098754f2bb11:0x2df0f60a7b61ed63!2sRijschool+Baas!8m2!3d52.3448173!4d4.9104269!16s%2Fg%2F1thw1byk!3m5!1s0x47c6098754f2bb11:0x2df0f60a7b61ed63!8m2!3d52.3448173!4d4.9104269!16s%2Fg%2F1thw1byk">Vierkante wielen<br>
                    Pauwenlaan 69 <br>
                    1392 NA Amsterdam
</a>
            </div>
            <div class="footer-row-3">
                <a href="../david/instructeur_login.php">Inloggen instructeur</a><br>
                <br>
                <a href="../sultan/login.php">Inloggen rijschoolhouder</a>
            </div>
        </div>
    </div>
</body>

</html>

<!-- Keira Jol -->