Examen opdracht rijschool Keira, David en Sultan:

Maak nieuwe database aan (Database naam: autorijschool_vierkante_wielen.) en exporteer dan de bijgeleverde sql bestand.


Rijschoolhouder login: 
email: admin@gmail.com
ww: admin

Wagenlijst is geen knop voor dus die moet je appart van de rest openen.


Leerling login: 
Je kan ook leerlingen registreren en dan gebruiken maar deze bestaat al en heeft een les.
naam: keira
email: keiranaz1@icloud.com
ww: keira

Instructeur login:
Via de Admin page kan je instructeurs registreren en dan ook gebruiken maar dit is instructeur die al bestaat.
naam: david
email: david@hotmail.com
ww: david
(dagrooster laat aleen lessen van vandaag zien. voeg een les toe bij "les inplannen" in footer en zet het op de datum van vandaag)


Er zijn folders aangemaakt met namen bij elke naam is alles wat wie heeft gedaan.
